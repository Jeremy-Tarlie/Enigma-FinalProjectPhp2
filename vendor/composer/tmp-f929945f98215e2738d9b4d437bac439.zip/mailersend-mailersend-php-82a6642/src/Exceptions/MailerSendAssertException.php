<?php

namespace MailerSend\Exceptions;

class MailerSendAssertException extends MailerSendException
{
}
