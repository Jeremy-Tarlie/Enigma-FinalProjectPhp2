<?php

namespace MailerSend\Exceptions;

class MailerSendException extends \ErrorException
{
}
