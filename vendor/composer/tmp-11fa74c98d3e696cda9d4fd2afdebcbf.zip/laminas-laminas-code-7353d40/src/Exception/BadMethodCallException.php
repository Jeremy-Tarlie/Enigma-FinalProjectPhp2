<?php

namespace Laminas\Code\Exception;

class BadMethodCallException extends \BadMethodCallException implements
    ExceptionInterface
{
}
